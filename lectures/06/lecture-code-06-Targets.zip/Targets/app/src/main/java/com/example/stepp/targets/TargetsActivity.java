/*
 * CS 193A, Winter 2015, Marty Stepp
 * This activity is basically just an empty shell to hold the TargetsView.
 */

package com.example.stepp.targets;

import android.app.Activity;
import android.os.Bundle;

public class TargetsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_targets);
    }
}
