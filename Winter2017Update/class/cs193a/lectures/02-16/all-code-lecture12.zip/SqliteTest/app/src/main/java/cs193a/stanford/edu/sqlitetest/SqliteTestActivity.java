/*
 * CS 193A, Marty Stepp
 * This project lets you test SQLite queries by typing them into a simple app
 * and viewing the resulting rows that come back.
 *
 * @author Marty Stepp
 * @version 2017/02/17
 * - utilize SimpleTask
 * @version 2017/02/15 (Winter 2017)
 * - added query progress
 * @version 2016/05/16 (Spring 2016)
 * - initial version
 */

package cs193a.stanford.edu.sqlitetest;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;
import stanford.androidlib.*;
import stanford.androidlib.data.*;

public class SqliteTestActivity extends SimpleActivity {
    private static final String[] DATABASE_NAMES = {"simpsons", "world", "imdb", "babynames"};
    private static final int MAX_ROWS_TO_SHOW = 100;

    private SimpleProgressDialog progressDialog = null;
    private SimpleTask task = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite_test);
        handleEnterKeyPress($ET(R.id.query));
    }

    @Override
    public void onEnterKeyPress(View editText) {
        doQuery($ET(R.id.query).getText().toString());
    }

    public void queryClick(View view) {
        doQuery($ET(R.id.query).getText().toString());
    }

    public void resetClick(View view) {
        SimpleDialog.with(this)
                .showConfirmDialog("Reset all databases and add all rows to them? This can take a while.");
    }

    @Override
    public void onInputDialogClose(AlertDialog dialog, String input) {
        super.onInputDialogClose(dialog, input);
        if (input.equalsIgnoreCase("Yes")) {
            // run the resetDatabases method in a thread, one that is blessed by Android GUI
            // new ResetDatabasesTask().execute(DATABASE_NAMES);
            task = SimpleTask.with(this);
            task.execute(DATABASE_NAMES);
        }
    }

    @Override
    public void onPreExecute() {
        progressDialog = SimpleDialog.with(this)
                .showProgressDialog("Resetting databases...", /* max */ 100000);
    }

    @Override
    public void doInBackground(String... databases) {
        for (String dbname : DATABASE_NAMES) {
            task.publishProgress(0);
            deleteDatabase(dbname);
            SimpleDatabase.with(SqliteTestActivity.this)
                    // .setLogging(true)
                    .executeSqlFile(dbname, this);
        }
    }

    @Override
    public void onProgressUpdate(int progress) {
        progressDialog.setProgress(progress, /* closeIfFinished */ false);
    }

    @Override
    public void onPostExecute() {
        progressDialog.hide();
    }

    @Override
    public void queryUpdated(String query, double completed) {
        int completeInt = (int) (100000 * completed);
        task.publishProgress(completeInt);
        if (completeInt == 100000) {
            // progressDialog.hide();
        }
    }

    public void radioClick(View view) {
        ImageView img = findImageView(R.id.databaseimage);
        if (img == null) {
            return;
        }
        if (findRadioButton(R.id.simpsonsradio).isChecked()) {
            img.setImageResource(R.drawable.simpsons);
        } else if (findRadioButton(R.id.worldradio).isChecked()) {
            img.setImageResource(R.drawable.world);
        } else if (findRadioButton(R.id.imdbradio).isChecked()) {
            img.setImageResource(R.drawable.imdb);
        } else if (findRadioButton(R.id.babynamesradio).isChecked()) {
            img.setImageResource(R.drawable.babynames);
        }
    }

    private void doQuery(String query) {
        TableLayout table = find(R.id.resultstable);
        table.removeAllViews();

        query = query.trim();
        String name = "";
        if (findRadioButton(R.id.simpsonsradio).isChecked()) {
            name = "simpsons";
        } else if (findRadioButton(R.id.worldradio).isChecked()) {
            name = "world";
        } else if (findRadioButton(R.id.imdbradio).isChecked()) {
            name = "imdb";
        } else if (findRadioButton(R.id.babynamesradio).isChecked()) {
            name = "babynames";
        }
        SQLiteDatabase db = openOrCreateDatabase(name);

        try {
            if (query.toLowerCase().startsWith("select")) {
                // select query
                Cursor cr = db.rawQuery(query, null);

                int cols = cr.getColumnCount();
                float fontSize = 0;
                if (cols >= 6) {
                    fontSize = new TextView(this).getTextSize() - 2;
                }
                if (!cr.moveToFirst()) {
                    toast("No results found.");
                    return;
                }

                // make header row
                TableRow headerRow = new TableRow(this);
                TableRow.LayoutParams rowParams = new TableRow.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                rowParams.weight = 1;
                rowParams.setMargins(2, 2, 2, 2);
                headerRow.setLayoutParams(rowParams);
                for (int c = -1; c < cols; c++) {
                    TextView tv = makeTextView(c >= 0 ? cr.getColumnName(c) : "#", headerRow, fontSize);
                    tv.setTypeface(null, Typeface.BOLD);
                    tv.setBackgroundColor(0xff333333);
                    tv.setTextColor(0xffdddddd);
                }
                table.addView(headerRow);

                int i = 1;
                do {
                    String line = "";
                    TableRow row = new TableRow(this);
                    row.setLayoutParams(rowParams);

                    int backgroundColor = (i % 2 == 0) ? 0xffeeeeee : 0xffffffff;

                    makeTextView(String.valueOf(i), row, fontSize).setBackgroundColor(backgroundColor);
                    for (int c = 0; c < cols; c++) {
                        String colValue = getColumnValue(cr, c);
                        line += " \t " + colValue;
                        makeTextView(colValue, row, fontSize).setBackgroundColor(backgroundColor);
                    }
                    log("query result " + i + ": " + line);
                    table.addView(row);

                    i++;
                    if (i > MAX_ROWS_TO_SHOW) {
                        log("aborting after " + MAX_ROWS_TO_SHOW + " rows.");
                        break;
                    }
                } while (cr.moveToNext());

                table.postInvalidate();
                toast("Query complete: " + (i - 1) + " rows.");
            } else {
                // other query; insert, update, delete, etc.
                log("running query: " + query);
                db.execSQL(query);
                log("finished running query");
                toast("Query complete.");
            }
        } catch (SQLiteException sqle) {
            log(sqle);

            String msg = sqle.getMessage();
            int index = msg.indexOf(", while compiling");
            if (index >= 0) {
                msg = msg.substring(0, index);
            }
            index = msg.indexOf(" (code");
            if (index >= 0) {
                msg = msg.substring(0, index);
            }
            toast(msg);
        }
    }

    private TextView makeTextView(String text, ViewGroup container, float fontSize) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setBackgroundColor(0xffffffff);
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.weight = 1;
        params.setMargins(2, 2, 2, 2);
        textView.setLayoutParams(params);
        textView.setPadding(1, 1, 1, 1);
        if (fontSize > 0) {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize);
        }
        container.addView(textView);
        return textView;
    }

    private String getColumnValue(Cursor cr, int c) {
        String colValue = "";
        int type = cr.getType(c);
        if (type == Cursor.FIELD_TYPE_FLOAT) {
            colValue = String.valueOf(cr.getFloat(c));
        } else if (type == Cursor.FIELD_TYPE_INTEGER) {
            colValue = String.valueOf(cr.getInt(c));
        } else if (type == Cursor.FIELD_TYPE_NULL) {
            colValue = "NULL";
        } else if (type == Cursor.FIELD_TYPE_STRING) {
            colValue = String.valueOf(cr.getString(c));
        }
        return colValue;
    }
}
