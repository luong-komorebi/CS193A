/*
 * CS 193A, Marty Stepp
 * This program is a quick demo of the Firebase remote database system.
 * The program allows a student to "log in" to a Simpsons grade database and
 * looks up their grades in the GradesActivity.
 */

package cs193a.stanford.edu.simpsongrades;

import android.os.Bundle;
import android.view.View;
import stanford.androidlib.*;

public class LoginActivity extends SimpleActivity {
    public static final String FIREBASE_USERNAME = "stepp@stanford.edu";
    public static final String FIREBASE_PASSWORD = "csroxx";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // TODO: connect to Firebase
    }

    public void loginClick(View view) {
        String name = $ET(R.id.name).getText().toString();

        // TODO: look up this person's password in Firebase
    }
}
