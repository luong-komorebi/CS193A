/*
 * CS 193A, Marty Stepp
 * This view draws the main graphics of the Lunar Lander game.
 * Today's version adds some new features (asteroids, etc.)
 * as well as Localization features to work in multiple languages.
 */

package cs193a.stanford.edu.lunarlander;

import android.content.Context;
import android.graphics.*;
import android.util.*;
import android.view.*;
import java.util.*;
import stanford.androidlib.*;
import stanford.androidlib.graphics.*;
import stanford.androidlib.util.*;

public class LanderCanvas extends GCanvas {
    // maximum velocity at which the rocket can hit the ground without crashing
    private static final float MAX_SAFE_LANDING_VELOCITY = 7.0f;

    private static final float ASTEROID_VELOCITY = -12.0f;

    // downward acceleration due to gravity
    private static final float GRAVITY_ACCELERATION = .5f;

    // upward acceleration due to thrusters
    private static final float THRUST_ACCELERATION = -.3f;

    // private fields


    /*
     * Required auto-generated constructor.
     */
    public LanderCanvas(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /*
     * Called when the GCanvas is being created.
     * Sets up the sprite objects and adds them to the screen.
     */
    @Override
    public void init() {
        // TODO
    }

    /*
     * Called by the GCanvas internal animation loop each time the animation ticks,
     * 20 times per second.
     * Updates the sprites and checks for collisions.
     */
    @Override
    public void onAnimateTick() {
        super.onAnimateTick();

        // TODO
    }

    /*
     * Called when user clicks Play Game button.
     * Starts a new game.
     */
    public void startGame() {
        // TODO
    }

    /*
     * Called when user clicks Stop Game button.
     * Ends the game.
     */
    public void stopGame() {
        // TODO
    }
}
