/*
 * CS 193A, Marty Stepp
 * This class is a graphical view of a simple animated app
 * with a ball that moves around and bounces off the edges of the screen.
 */

package cs193a.stanford.edu.bouncingball;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;
import stanford.androidlib.graphics.*;

public class BouncingBallView extends GCanvas {
    private static final float BALL_SIZE = 100;
    private static final float BALL_MAX_VELOCITY = 50;

    /** Empty required constructor. */
    public BouncingBallView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /*
     * Sets up the initial state of the view and sprites.
     */
    public void init() {
        // TODO
    }

    /*
     * This method draws the bouncing ball and Pac-Man on the screen,
     * and also updates their positions for the next time the screen
     * is redrawn.
     */
    @Override
    public void onAnimateTick() {
        super.onAnimateTick();

        // TODO
    }
}
